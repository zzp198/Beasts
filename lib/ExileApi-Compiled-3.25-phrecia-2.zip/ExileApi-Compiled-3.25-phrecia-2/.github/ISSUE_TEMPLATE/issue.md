---
name: Issue
about: Generic issue
title: ''
labels: ''
assignees: instantsc

---

If you insult anyone, throw baseless accusations around or are not polite in your request, you will not be able to make any more issues.
